// import React from 'react'

// export default function Popup(props) {
//     const [popup,setPop]=useState(false)
//     const handleClickOpen=()=>{
//         setPop(!popup)
//     };
//     const closePopup= () =>{
//         setPop(false)
//     };

//   return (
//     <>
//     { popup ? <Forgetpass data={closePopup}/>: ""}
//     </>
//   )
// }
